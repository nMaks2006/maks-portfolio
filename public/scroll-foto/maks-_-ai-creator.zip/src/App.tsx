import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, X, Mail, Send, CheckCircle2, Sparkles, Wand2, Layers, Camera } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  category: string;
  description: string;
}

const PROJECTS: Project[] = [
  {
    id: 'cyber-fashion',
    title: 'Aetheria Studio Editorial',
    category: 'High-Fashion & AI Staging',
    description: 'Avant-garde digital fashion collection created with customized AI neural style synthesis for a luxury Parisian magazine.',
  },
  {
    id: 'luxe-perfume',
    title: 'Lumière Fragrance Commercial Spot',
    category: 'Product Visualization',
    description: 'Photorealistic liquid simulations, glass refractions, and ethereal lighting for a premiere fragrance brand.',
  },
  {
    id: 'spatial-ai',
    title: 'Neo-Tokyo Concept Architecture',
    category: 'Futuristic Environments',
    description: 'Surreal spatial design and architectural concepts synthesized using generative multi-model AI workflows.',
  },
];

export default function App() {
  const [activeNav, setActiveNav] = useState<'Home' | 'About' | 'Projects'>('Home');
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isProjectsOpen, setIsProjectsOpen] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const aboutRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);

  const handleNavClick = (item: 'Home' | 'About' | 'Projects') => {
    setActiveNav(item);
    if (item === 'About') {
      aboutRef.current?.scrollIntoView({ behavior: 'smooth' });
    } else if (item === 'Home') {
      heroRef.current?.scrollIntoView({ behavior: 'smooth' });
    } else if (item === 'Projects') {
      setIsProjectsOpen(true);
    }
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setIsContactOpen(false);
      setEmail('');
      setMessage('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-black text-white font-['DM_Sans'] flex flex-col justify-between pt-4 sm:pt-6 lg:pt-8 px-6 sm:px-10 lg:px-14 pb-16 selection:bg-orange-500 selection:text-white scroll-smooth">
      {/* Main Container */}
      <div className="w-full max-w-7xl mx-auto flex flex-col justify-between relative">
        
        {/* Navigation Bar */}
        <header ref={heroRef} className="flex items-center justify-between z-10">
          {/* Brand Logo */}
          <div 
            onClick={() => handleNavClick('Home')}
            className="text-xl sm:text-2xl font-bold tracking-tight flex items-center gap-1.5 cursor-pointer select-none"
          >
            <span className="text-white">Maks</span>
            <span className="text-[#ff5722]">| AI-Creator</span>
          </div>

          {/* Nav Links */}
          <nav className="hidden sm:flex items-center gap-8 text-sm md:text-base font-medium">
            {(['Home', 'About', 'Projects'] as const).map((item) => {
              const isActive = activeNav === item;
              return (
                <button
                  key={item}
                  onClick={() => handleNavClick(item)}
                  className={`transition-colors duration-200 cursor-pointer ${
                    isActive ? 'text-[#ff5722] font-semibold' : 'text-white/70 hover:text-white'
                  }`}
                >
                  {item}
                </button>
              );
            })}
          </nav>

          {/* Get in Touch Button */}
          <button
            onClick={() => setIsContactOpen(true)}
            className="group flex items-center gap-3 bg-white text-black pl-5 pr-2 py-2 rounded-full font-semibold text-sm transition-all duration-300 hover:bg-white/90 hover:scale-[1.02] cursor-pointer"
          >
            <span>Get in Touch</span>
            <div className="w-8 h-8 rounded-full bg-[#ff5722] text-white flex items-center justify-center transition-transform duration-300 group-hover:rotate-45">
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
            </div>
          </button>
        </header>

        {/* Hero Content Section */}
        <main className="pt-6 sm:pt-10 lg:pt-12 pb-16 lg:pb-28 flex flex-col justify-center items-start max-w-4xl z-10">
          {/* Small Greeting */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-base sm:text-lg lg:text-xl text-white/90 font-normal mb-2 sm:mb-3 tracking-tight"
          >
            Hey, I'm Maks
          </motion.p>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-6xl lg:text-7xl xl:text-8xl font-bold tracking-tight text-white leading-[0.95] select-none mb-5 lg:mb-6"
          >
            AI Visual
            <br />
            Creator.
          </motion.h1>

          {/* Tagline / Subheading */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-2xl sm:text-3xl lg:text-4xl text-white font-medium leading-tight mb-4 max-w-2xl"
          >
            Bringing impossible visuals to life with AI.
          </motion.h2>

          {/* Subtitle / Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="text-white/70 text-base sm:text-lg max-w-2xl font-normal leading-relaxed mb-6 lg:mb-8"
          >
            From commercial product spots to high-fashion studio editorials — creating visuals that captivate and convert.
          </motion.p>

          {/* CTA Link */}
          <motion.button
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            onClick={() => handleNavClick('About')}
            className="inline-flex items-center gap-2 text-sm sm:text-base font-medium text-[#ff5722] hover:text-[#ff5722]/80 transition-colors group cursor-pointer"
          >
            <span>Read About Me & My Work</span>
            <ArrowUpRight className="w-4 h-4 sm:w-5 sm:h-5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </motion.button>
        </main>

        {/* Dedicated "About Me" Section (Replaces old pillars footer) */}
        <section
          id="about-section"
          ref={aboutRef}
          className="z-10 pt-16 lg:pt-24 border-t border-white/10 transition-all duration-500"
        >
          <div className="flex flex-col gap-6 items-start text-left">
            {/* About Section Header */}
            <div className="flex items-center justify-between w-full flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-[#ff5722] animate-pulse" />
                <h3 className="text-[11px] sm:text-xs font-mono tracking-widest uppercase text-white/60">
                  About Me — Maks
                </h3>
              </div>
              <span className="text-[11px] font-mono text-white/40">
                AI Visual Synthesis & Visual Direction
              </span>
            </div>

            {/* Main About Description & Specializations */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start w-full">
              {/* Bio Paragraph */}
              <div className="lg:col-span-7 space-y-3.5 text-left">
                <p className="text-base sm:text-lg lg:text-xl text-white/90 font-light leading-relaxed">
                  I am a digital creator specializing in <span className="text-white font-medium">next-generation AI visual synthesis</span>, bridging artistic direction with state-of-the-art generative technology.
                </p>
                <p className="text-xs sm:text-sm text-white/60 font-normal leading-relaxed max-w-xl">
                  My work focuses on producing hyper-realistic commercial visuals, high-fashion editorials, futuristic concept architecture, and high-impact brand assets. By leveraging custom AI workflows and neural style tuning, I transform ambitious creative concepts into stunning visual reality with unprecedented speed and precision.
                </p>
              </div>

              {/* Specialization Cards / Stats */}
              <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all">
                  <Camera className="w-5 h-5 text-[#ff5722] mb-2.5" />
                  <div>
                    <h4 className="text-white font-medium text-xs sm:text-sm mb-0.5">Commercial & Fashion</h4>
                    <p className="text-[11px] text-white/50 leading-normal">Studio-grade lighting, hyper-realistic textures, and editorial styling.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all">
                  <Wand2 className="w-5 h-5 text-[#ff5722] mb-2.5" />
                  <div>
                    <h4 className="text-white font-medium text-xs sm:text-sm mb-0.5">AI Neural Pipelines</h4>
                    <p className="text-[11px] text-white/50 leading-normal">Custom LoRA training, prompt architecture, and multi-model workflows.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all">
                  <Layers className="w-5 h-5 text-[#ff5722] mb-2.5" />
                  <div>
                    <h4 className="text-white font-medium text-xs sm:text-sm mb-0.5">Product Spot Design</h4>
                    <p className="text-[11px] text-white/50 leading-normal">High-converting visual assets tailored for premium brands.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all">
                  <Sparkles className="w-5 h-5 text-[#ff5722] mb-2.5" />
                  <div>
                    <h4 className="text-white font-medium text-xs sm:text-sm mb-0.5">Creative Direction</h4>
                    <p className="text-[11px] text-white/50 leading-normal">Full end-to-end visual moodboards, staging, and final rendering.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Projects Modal */}
      <AnimatePresence>
        {isProjectsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-2xl bg-[#0d0d0d] border border-white/15 rounded-3xl p-6 sm:p-8 relative shadow-2xl max-h-[85vh] overflow-y-auto"
            >
              <button
                onClick={() => setIsProjectsOpen(false)}
                className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5 text-[#ff5722]" />
                <h3 className="text-xl font-bold text-white">Featured AI Visual Projects</h3>
              </div>
              <p className="text-white/60 text-sm mb-6">
                Selected commercial and conceptual visual series created by Maks.
              </p>

              <div className="space-y-4">
                {PROJECTS.map((project) => (
                  <div
                    key={project.id}
                    className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-[#ff5722]/50 transition-all group"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono text-[#ff5722]">{project.category}</span>
                      <ArrowUpRight className="w-4 h-4 text-white/40 group-hover:text-white transition-colors" />
                    </div>
                    <h4 className="text-lg font-semibold text-white mb-1">{project.title}</h4>
                    <p className="text-sm text-white/70">{project.description}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Contact Modal */}
      <AnimatePresence>
        {isContactOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-md bg-[#0f0f0f] border border-white/15 rounded-3xl p-6 sm:p-8 relative shadow-2xl"
            >
              <button
                onClick={() => setIsContactOpen(false)}
                className="absolute top-6 right-6 text-white/60 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <Mail className="w-5 h-5 text-[#ff5722]" />
                <h3 className="text-xl font-bold text-white">Get in Touch</h3>
              </div>
              <p className="text-white/70 text-sm mb-6">
                Direct inquiries for commercial AI visual projects, editorial direction, and custom AI artwork.
              </p>

              {formSubmitted ? (
                <div className="py-8 text-center flex flex-col items-center justify-center">
                  <CheckCircle2 className="w-12 h-12 text-[#ff5722] mb-3 animate-bounce" />
                  <p className="text-white font-medium text-lg">Message Sent!</p>
                  <p className="text-white/60 text-sm mt-1">Maks will get back to you soon.</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-mono text-white/60 mb-1.5 uppercase tracking-wider">
                      Your Email
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="alex@company.com"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#ff5722] transition-colors text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono text-white/60 mb-1.5 uppercase tracking-wider">
                      Project Scope
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your visual concept or commercial project..."
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:outline-none focus:border-[#ff5722] transition-colors text-sm resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-[#ff5722] hover:bg-[#ff5722]/90 text-white font-semibold py-3.5 px-6 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#ff5722]/20"
                  >
                    <span>Send Inquiry</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
